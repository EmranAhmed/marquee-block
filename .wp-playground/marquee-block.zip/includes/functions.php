<?php
	/**
	 * Utility Functions.
	 *
	 * @package    StorePress/MarqueeBlock
	 * @since      1.0.0
	 * @version    1.0.0
	 */

	namespace StorePress\MarqueeBlock;

	defined( 'ABSPATH' ) || die( 'Keep Silent' );
