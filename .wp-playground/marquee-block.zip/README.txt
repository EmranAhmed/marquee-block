=== Marquee Block ===
Contributors: EmranAhmed
Requires at least: 6.4
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.0.1
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Marquee block is CSS based animation block to display scrolling text, images and any kinds of blocks horizontally and vertically.

== Description ==

Marquee block adds a touch of movement and interactivity to your site and help to capture attention and engage your site visitors in a unique way.



== Installation ==
= Minimum Requirements =

* PHP 7.4 or greater is required (PHP 8.0 or greater is recommended)
* MySQL 5.6 or greater, OR MariaDB version 10.1 or greater, is required

= Automatic installation =

Automatic installation is the easiest option -- WordPress will handle the file transfer, and you won’t need to leave your web browser. To do an automatic install, log in to your WordPress dashboard, navigate to the Plugins menu, and click “Add New.”

In the search field type “Marquee Block” then click “Search Plugins.” Once you’ve found us,  you can view details about it such as the point release, rating, and description. Most importantly of course, you can install it by! Click “Install Now,” and WordPress will take it from there.

= Manual installation =

Manual installation method requires downloading the “Marquee Block” plugin and uploading it to your web server via your favorite FTP application. The WordPress codex contains [instructions on how to do this here](https://wordpress.org/support/article/managing-plugins/#manual-plugin-installation).

== Frequently Asked Questions ==

== Screenshots ==

== Changelog ==
= 1.0.1 - 2024-07-25 =
- Update required by org

= 1.0.0 - 2024-06-10 =
- Initial release

